package com.journaldev.spring;

import java.io.Serializable;
import java.util.List;

import com.google.api.client.util.DateTime;

public class ScreenResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long bookingId;
	
	private DateTime starTime;
	
	private DateTime endTime;

	private List<RoomDetails> screenDetails;

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public DateTime getStarTime() {
		return starTime;
	}

	public void setStarTime(DateTime starTime) {
		this.starTime = starTime;
	}

	public DateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	public List<RoomDetails> getScreenDetails() {
		return screenDetails;
	}

	public void setScreenDetails(List<RoomDetails> screenDetails) {
		this.screenDetails = screenDetails;
	}

	

}
