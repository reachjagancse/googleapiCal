package com.journaldev.spring;

import java.io.Serializable;

import com.google.api.client.util.DateTime;

public class RoomDetails implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DateTime startTime;
	private DateTime endTime;
	private String medialink;
	public DateTime getStartTime() {
		return startTime;
	}
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}
	public DateTime getEndTime() {
		return endTime;
	}
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}
	public String getMedialink() {
		return medialink;
	}
	public void setMedialink(String medialink) {
		this.medialink = medialink;
	}
	
	

}
